#!/bin/bash

RESULT="$(dirname "$0")/result_$(date '+%y-%m-%d').txt"

echo "====================================================" >> ${RESULT} 
echo "======================= 2. 파일 시스템 ===================" >> ${RESULT}
echo "====================================================" >> ${RESULT}

for FILE_COUNT in {01..16}
do
	./debian_script/filesystem/filesystem_${FILE_COUNT}.sh
	echo ./debian_script/filesystem/filesystem_${FILE_COUNT}.sh
	cat ./debian_script/filesystem/result_filesystem_${FILE_COUNT}.sh.txt >> ${RESULT}
	echo "" >> ${RESULT}
	if [ $FILE_COUNT -eq 16 ]
	then
		continue
	fi
	echo "****************************************************" >> ${RESULT}
	echo "" >> ${RESULT}
done
