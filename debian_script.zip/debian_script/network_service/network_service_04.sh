#!/bin/bash
LANG=ko_KR.UTF-8

CURRENT_PATH=`dirname $0`

NAME=`basename $0`

ETC_PATH="/etc"

RESULT="$CURRENT_PATH/result_$NAME.txt"

#리눅스 버전 : Debian 7
#계정관리 3.4 NIS(Netsork Information Service) 제한(상)
#53p
echo "[LDv7-3.4]" > ${RESULT} 2>&1
echo "3.4 NIS(Netsork Information Service) 제한(상)" >> ${RESULT} 2>&1
echo "[점검현황]" >> ${RESULT} 2>&1
NIS=$(ps -ef | grep yp | grep -v --color=auto yp)
echo $NIS >> ${RESULT} 2>&1
echo "[상태]" >> ${RESULT} 2>&1
STATUS="양호"
if [ -n "$NIS" ]
then
	STATUS="취약"
fi

echo $STATUS >> ${RESULT} 2>&1
echo "[점검기준 ]" >> ${RESULT} 2>&1
echo "양호: 불필요한 서비스가 비활성화 되어있는 경우" >> ${RESULT} 2>&1
echo "취약: 불필요한 서비스가 활성화 되어있는 경우" >> ${RESULT} 2>&1
