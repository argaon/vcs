#!/bin/bash
LANG=ko_KR.UTF-8

CURRENT_PATH=`dirname $0`

NAME=`basename $0`

ETC_PATH="/etc"

RESULT="$CURRENT_PATH/result_$NAME.txt"

#리눅스 버전 : Debian 7
#계정관리 3.7 서비스 Banner 관리(중)

echo "[LDv7-3.7]" > ${RESULT} 2>&1
echo "3.7 서비스 Banner 관리(중)" >> ${RESULT} 2>&1
echo "[점검현황]" >> ${RESULT} 2>&1
BANNER=$(cat /etc/motd)
echo $BANNER >> ${RESULT} 2>&1
STATUS="양호"
if [ -n "$BANNER" ]
then
	STATUS="취약"
fi
echo "[상태]" >> ${RESULT} 2>&1
echo $STATUS >> ${RESULT} 2>&1
echo "[점검기준 ]" >> ${RESULT} 2>&1
echo "양호: 서버 및 Telnet 서비스에 로그온 메시지가 설정되어 있는 경우" >> ${RESULT} 2>&1
echo "취약: 서버 및 Telnet 서비스에 로그온 메시지가 설정되어 있지 않은 경우" >> ${RESULT} 2>&1
