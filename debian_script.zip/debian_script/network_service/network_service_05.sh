#!/bin/bash
LANG=ko_KR.UTF-8

CURRENT_PATH=`dirname $0`

NAME=`basename $0`

ETC_PATH="/etc"

RESULT="$CURRENT_PATH/result_$NAME.txt"

#리눅스 버전 : Debian 7
#계정관리 3.5 r' commands 서비스 제거(상)
#48p
echo "[LDv7-3.5]" > ${RESULT} 2>&1
echo "3.5 r' commands 서비스 제거(상)" >> ${RESULT} 2>&1
echo "[점검현황]" >> ${RESULT} 2>&1
ls -al /etc/hosts.equiv >> ${RESULT} 2>&1
ls -al $HOME/.rhosts >> ${RESULT} 2>&1
STATUS="양호"
function get_result()
{
	if [ $(ls -l $1 2>/dev/null | awk -F ' ' "{print \$3}") != "root" ]
	then
		STATUS="취약"
	fi
	for i in {1..3}
		do
				PERM=$(stat -c '%a' $1 | awk -F '' "{print \$"${i}"}")
				if [ ${i} -eq 1 ] 
				then
					if [ ${PERM} -gt 6 ]
					then
						STATUS="취약"
					fi
				fi
				if [ ${i} -eq 2 ] 
				then
					if [ ${PERM} -gt 0 ]
					then
						STATUS="취약"
					fi
				fi
				if [ ${i} -eq 3 ] 
				then
					if [ ${PERM} -gt 0 ]
					then
						STATUS="취약"
					fi
				fi
		done
}
get_result /etc/hosts.equiv
get_result $HOME/.rhosts

echo "[상태]" >> ${RESULT} 2>&1
echo $STATUS >> ${RESULT} 2>&1
echo "[점검기준 ]" >> ${RESULT} 2>&1
echo "양호: login, shell, exec 서비스를 사용하지 않거나 , 사용 시 아래와 같은 설정이 적용된 경우" >> ${RESULT} 2>&1
echo "1. /etc/hosts.equiv 및 $HOME/.rhosts 파일 소유자가 root 또는 , 해당 계정인 경우" >> ${RESULT} 2>&1
echo "2. /etc/hosts.equiv 및 $HOME/.rhosts 파일 권한이 600 이하인 경우" >> ${RESULT} 2>&1
echo "3. /etc/hosts.equiv 및 $HOME/.rhosts 파일 설정에 ‘+’ 설정이 없는 경우" >> ${RESULT} 2>&1
echo "취약: login, shell, exec 서비스를 사용하고 , 위와 같은 설정이 적용되지 않은 경우" >> ${RESULT} 2>&1
