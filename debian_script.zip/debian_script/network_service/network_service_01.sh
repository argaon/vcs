#!/bin/bash
LANG=ko_KR.UTF-8

CURRENT_PATH=`dirname $0`

NAME=`basename $0`

ETC_PATH="/etc"

RESULT="$CURRENT_PATH/result_$NAME.txt"

#리눅스 버전 : Debian 7
#계정관리 3.1 RPC(Remote Procedure Call) 서비스 제한(중)

echo "[LDv7-3.1]" > ${RESULT} 2>&1
echo "3.1 RPC(Remote Procedure Call) 서비스 제한(중)" >> ${RESULT} 2>&1
echo "[점검현황]" >> ${RESULT} 2>&1
FILE_LIST=(rpc.cmsd rpc.ttdbserverd sadmind rusersd walld sprayd rstatd rpc.nisd rexd
rpc.pcnfsd rpc.statd rpc.ypupdated rpc.rquotad kcms_server cachefsd)
ACTIVE_SERVICE=''
COMMA=','
STATUS="양호"
function check_service()
{
	FILE_CONTENTS=$(cat /etc/xinetd.d/$1 2>/dev/null)
	FILE_CONTENTS=$(echo $FILE_CONTENTS | sed 's/ //g')
	if [[ "$FILE_CONTENTS" =~ "disable=no" ]]
	then
		STATUS="취약"
		ACTIVE_SERVICE=$ACTIVE_SERVICE$COMMA$1
	fi
}

for FILE in ${FILE_LIST[@]}
do
	check_service $FILE
done

echo "${ACTIVE_SERVICE:1}" >> ${RESULT} 2>&1
echo "[상태]" >> ${RESULT} 2>&1
echo $STATUS >> ${RESULT} 2>&1
echo "[점검 기준 ]" >> ${RESULT} 2>&1
echo "양호: 불필요한 서비스가 비활성화 되어 있는 경우 " >> ${RESULT} 2>&1
echo "취약: 불필요한 서비스가 활성화 되어 있는 경우" >> ${RESULT} 2>&1
