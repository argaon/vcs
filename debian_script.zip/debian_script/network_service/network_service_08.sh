#!/bin/bash
LANG=ko_KR.UTF-8

CURRENT_PATH=`dirname $0`

NAME=`basename $0`

ETC_PATH="/etc"

RESULT="$CURRENT_PATH/result_$NAME.txt"

#리눅스 버전 : Debian 7
#계정관리 3.8 Session Timeout 설정(하)
#31
echo "[LDv7-3.8]" > ${RESULT} 2>&1
echo "3.8 Session Timeout 설정(하)" >> ${RESULT} 2>&1
echo "[점검현황]" >> ${RESULT} 2>&1
TMOUT=$(cat /etc/profile | grep "TMOUT")
echo $TMOUT >> ${RESULT} 2>&1
echo "[상태]" >> ${RESULT} 2>&1
STATUS="취약"
if [ -n "$TMOUT" ]
then
	TMOUT=$(echo $TMOUT | sed 's/[^0-9]//g')
	if [ ${TMOUT} -le 600 ]
	then
		STATUS="양호"
	fi
fi

echo $STATUS >> ${RESULT} 2>&1
echo "[점검 기준 ]" >> ${RESULT} 2>&1
echo "양호: Session Timeout 이 600 초 (10 분 ) 이하로 설정되어 있는 경우" >> ${RESULT} 2>&1
echo "취약: Session Timeout 이 600 초 (10 분 ) 이하로 설정되지 않은 경우" >> ${RESULT} 2>&1
