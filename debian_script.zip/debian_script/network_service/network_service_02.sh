#!/bin/bash
LANG=ko_KR.UTF-8

CURRENT_PATH=`dirname $0`

NAME=`basename $0`

ETC_PATH="/etc"

RESULT="$CURRENT_PATH/result_$NAME.txt"

#리눅스 버전 : Debian 7
#계정관리 3.2 NFS(Network File System) 제한(상)
#69p
echo "[LDv7-3.2]" > ${RESULT} 2>&1
echo "3.2 NFS(Network File System) 제한(상)" >> ${RESULT} 2>&1
echo "[점검현황]" >> ${RESULT} 2>&1
NFS=$(ps -ef | grep nfsd | grep -v --color=auto nfsd)
echo $NFS >> ${RESULT} 2>&1
echo "[상태]" >> ${RESULT} 2>&1
STATUS="양호"
if [ -n "$NFS" ]
then
	STATUS="취약"
fi

echo $STATUS >> ${RESULT} 2>&1
echo "[점검 기준 ]" >> ${RESULT} 2>&1
echo "양호: NFS 서비스 관련 데몬이 비활성화 되어 있는 경우" >> ${RESULT} 2>&1
echo "취약: NFS 서비스 관련 데몬이 활성화 되어 있는 경우" >> ${RESULT} 2>&1
