#!/bin/bash
LANG=ko_KR.UTF-8

CURRENT_PATH=`dirname $0`

NAME=`basename $0`

ETC_PATH="/etc"

RESULT="$CURRENT_PATH/result_$NAME.txt"

#리눅스 버전 : Debian 7
#계정관리 3.9 telnet, ssh 접근 제한(상)
#50p
echo "[LDv7-3.9]" > ${RESULT} 2>&1
echo "3.9 telnet, ssh 접근 제한(상)" >> ${RESULT} 2>&1
echo "[점검현황]" >> ${RESULT} 2>&1
DENY=$(grep -r "ALL Deny" /etc/hosts.deny)
cat /etc/hosts.deny >> ${RESULT} 2>&1
STATUS="취약"
echo "[상태]" >> ${RESULT} 2>&1
if [ -n "$DENY" ]
then
	STATUS="양호"
fi
echo $STATUS >> ${RESULT} 2>&1
echo "[점검 기준 ]" >> ${RESULT} 2>&1
echo "양호: /etc/hosts.deny 파일에 ALL Deny 설정 후 /etc/hosts.allow 파일에 접근을 허용할 특정 호스트를 등록한 경우" >> ${RESULT} 2>&1
echo "취약: 위와 같이 설정되지 않은 경우" >> ${RESULT} 2>&1
