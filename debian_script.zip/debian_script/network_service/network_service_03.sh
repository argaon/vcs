#!/bin/bash
LANG=ko_KR.UTF-8

CURRENT_PATH=`dirname $0`

NAME=`basename $0`

ETC_PATH="/etc"

RESULT="$CURRENT_PATH/result_$NAME.txt"

#리눅스 버전 : Debian 7
#계정관리 3.3 automountd 서비스 제거(중)
#72p
echo "[LDv7-3.3]" > ${RESULT} 2>&1
echo "3.3 automountd 서비스 제거(중)" >> ${RESULT} 2>&1
AUTOMOUNT=$(ps -ef | grep automount | grep -v --color=auto automount)
echo $AUTOMOUNT >> ${RESULT} 2>&1
echo "[상태]" >> ${RESULT} 2>&1
STATUS="양호"
if [ -n "$AUTOMOUNT" ]
then
	STATUS="취약"
fi

echo $STATUS >> ${RESULT} 2>&1
echo "[점검기준 ]" >> ${RESULT} 2>&1
echo "양호: automountd 서비스가 비활성화 되어 있는 경우" >> ${RESULT} 2>&1
echo "취약: automountd 서비스가 활성화 되어 있는 경우" >> ${RESULT} 2>&1
