#!/bin/bash

RESULT="$(dirname "$0")/result_$(date '+%y-%m-%d').txt"

echo "====================================================" >> ${RESULT} 
echo "================= 3. 네트워크 서비스 =================" >> ${RESULT}
echo "====================================================" >> ${RESULT}

for FILE_COUNT in {01..09}
do
	./debian_script/network_service/network_service_${FILE_COUNT}.sh
	echo ./debian_script/network_service/network_service_${FILE_COUNT}.sh
	cat ./debian_script/network_service/result_network_service_${FILE_COUNT}.sh.txt >> ${RESULT}
	echo "" >> ${RESULT}
	if [ $FILE_COUNT -eq 09 ]
	then
		continue
	fi
	echo "****************************************************" >> ${RESULT}
	echo "" >> ${RESULT}
done
