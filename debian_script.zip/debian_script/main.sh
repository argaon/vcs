#!/bin/bash

RESULT="$(dirname "$0")/result_$(date '+%y-%m-%d').txt"

echo "====================================================" > ${RESULT} 
echo "==================== 1. 계정 관리 ===================" >> ${RESULT}
echo "====================================================" >> ${RESULT}

for FILE_COUNT in {01..08}
do
	account/account_${FILE_COUNT}.sh
	echo account/account_${FILE_COUNT}.sh
	cat account/result_account_${FILE_COUNT}.sh.txt >> ${RESULT}
	echo "" >> ${RESULT}
	if [ $FILE_COUNT -eq 08 ]
	then
		continue
	fi
	echo "****************************************************" >> ${RESULT}
	echo "" >> ${RESULT}
done

echo "====================================================" >> ${RESULT} 
echo "===================== 2. 파일 시스템 =================" >> ${RESULT}
echo "====================================================" >> ${RESULT}

for FILE_COUNT in {01..16}
do
	filesystem/filesystem_${FILE_COUNT}.sh
	echo filesystem/filesystem_${FILE_COUNT}.sh
	cat filesystem/result_filesystem_${FILE_COUNT}.sh.txt >> ${RESULT}
	echo "" >> ${RESULT}
	if [ $FILE_COUNT -eq 16 ]
	then
		continue
	fi
	echo "****************************************************" >> ${RESULT}
	echo "" >> ${RESULT}
done

echo "====================================================" >> ${RESULT} 
echo "================= 3. 네트워크 서비스 =================" >> ${RESULT}
echo "====================================================" >> ${RESULT}

for FILE_COUNT in {01..09}
do
	network_service/network_service_${FILE_COUNT}.sh
	echo network_service/network_service_${FILE_COUNT}.sh
	cat network_service/result_network_service_${FILE_COUNT}.sh.txt >> ${RESULT}
	echo "" >> ${RESULT}
	if [ $FILE_COUNT -eq 09 ]
	then
		continue
	fi
	echo "****************************************************" >> ${RESULT}
	echo "" >> ${RESULT}
done

echo "====================================================" >> ${RESULT} 
echo "==================== 4. 로그 관리 ===================" >> ${RESULT}
echo "====================================================" >> ${RESULT}

for FILE_COUNT in {01..02}
do
	log/log_${FILE_COUNT}.sh 2>/dev/null
	echo log/log_${FILE_COUNT}.sh 2>/dev/null
	cat log/result_log_${FILE_COUNT}.sh.txt >> ${RESULT} 2>/dev/null
	echo "" >> ${RESULT}
	if [ $FILE_COUNT -eq 02 ]
	then
		continue
	fi
	echo "****************************************************" >> ${RESULT}
	echo "" >> ${RESULT}
done

echo "====================================================" >> ${RESULT} 
echo "================= 5. 주요 응용 설정  ==================" >> ${RESULT}
echo "====================================================" >> ${RESULT}

for FILE_COUNT in {01..08}
do
	program_setting/program_setting_${FILE_COUNT}.sh 2>/dev/null
	echo program_setting/program_setting_${FILE_COUNT}.sh 2>/dev/null
	cat program_setting/result_program_setting_${FILE_COUNT}.sh.txt >> ${RESULT} 2>/dev/null
	echo "" >> ${RESULT}
	if [ $FILE_COUNT -eq 08 ]
	then
		continue
	fi
	echo "****************************************************" >> ${RESULT}
	echo "" >> ${RESULT}
done

echo "====================================================" >> ${RESULT} 
echo "=================== 6. 보안 패치 ====================" >> ${RESULT}
echo "====================================================" >> ${RESULT}

for FILE_COUNT in {01..01}
do
	patch/patch_${FILE_COUNT}.sh 2>/dev/null
	echo patch/patch_${FILE_COUNT}.sh 2>/dev/null
	cat patch/result_patch_${FILE_COUNT}.sh.txt >> ${RESULT} 2>/dev/null
	echo "" >> ${RESULT}
	if [ $FILE_COUNT -eq 01 ]
	then
		continue
	fi
	echo "****************************************************" >> ${RESULT}
	echo "" >> ${RESULT}
done

