#!/bin/bash

RESULT="$(dirname "$0")/result_$(date '+%y-%m-%d').txt"

echo "====================================================" > ${RESULT} 
echo "==================== 1. 계정 관리 ===================" >> ${RESULT}
echo "====================================================" >> ${RESULT}

for FILE_COUNT in {01..08}
do
	./debian_script/account/account_${FILE_COUNT}.sh
	echo ./debian_script/account/account_${FILE_COUNT}.sh
	cat ./debian_script/account/result_account_${FILE_COUNT}.sh.txt >> ${RESULT}
	echo "" >> ${RESULT}
	if [ $FILE_COUNT -eq 08 ]
	then
		continue
	fi
	echo "****************************************************" >> ${RESULT}
	echo "" >> ${RESULT}
done
