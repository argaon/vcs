#!/bin/sh
LANG=ko_KR.UTF-8

CURRENT_PATH=`dirname $0`

NAME=`basename $0`

ETC_PATH="/etc"

RESULT="$CURRENT_PATH/result_$NAME.txt"

#리눅스 버전 : Debian 7


echo "[LDv7-6.1]" > ${RESULT} 2>&1
echo "6.1 보안 패치 적용 (상)" >> ${RESULT} 2>&1
echo "[점검현황]" >> ${RESULT} 2>&1
echo "수동 점검 필요" >> ${RESULT} 2>&1
echo "[상태]" >> ${RESULT} 2>&1
echo "양호" >> ${RESULT} 2>&1
echo "[점검기준 ]" >> ${RESULT} 2>&1
echo "양호: 패치 적용 정책을 수립하여 주기적으로 패치를 관리하고 있는 경우" >> ${RESULT} 2>&1
echo "취약: 패치 적용 정책을 수립하지 않고 주기적으로 패치관리를 하지 않는 경우" >> ${RESULT} 2>&1

