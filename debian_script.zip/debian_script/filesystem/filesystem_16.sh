#!/bin/bash
LANG=ko_KR.UTF-8

CURRENT_PATH=`dirname $0`

NAME=`basename $0`

ETC_PATH="/etc"

RESULT="$CURRENT_PATH/result_$NAME.txt"

#리눅스 버전 : Debian 7
#계정관리 2.16 부팅 스크립트 파일 권한 설정(상)

echo "[LDv7-2.16]" > ${RESULT} 2>&1
echo "2.16 부팅 스크립트 파일 권한 설정(상)" >> ${RESULT} 2>&1
echo "[점검현황]" >> ${RESULT} 2>&1
NEW_LINE='
'
SCRIPT=$(ls -l /etc/init 2>/dev/null)
SCRIPT=$SCRIPT$NEW_LINE$(ls -l /etc/rc.d 2>/dev/null)
SCRIPT=$SCRIPT$NEW_LINE$(ls -l /etc/rc.d/init.d 2>/dev/null)
SCRIPT=$SCRIPT$NEW_LINE$(ls -l /etc/rc0.d 2>/dev/null)
SCRIPT=$SCRIPT$NEW_LINE$(ls -l /etc/rc1.d 2>/dev/null)
SCRIPT=$SCRIPT$NEW_LINE$(ls -l /etc/rc2.d 2>/dev/null)
SCRIPT=$SCRIPT$NEW_LINE$(ls -l /etc/rc3.d 2>/dev/null)
SCRIPT=$SCRIPT$NEW_LINE$(ls -l /etc/rc4.d 2>/dev/null)
SCRIPT=$SCRIPT$NEW_LINE$(ls -l /etc/rc5.d 2>/dev/null)
SCRIPT=$SCRIPT$NEW_LINE$(ls -l /etc/rc6.d 2>/dev/null)
SCRIPT=$SCRIPT$NEW_LINE$(ls -l /etc/rc0.d 2>/dev/null)
SCRIPT=$SCRIPT$NEW_LINE$(ls -l /etc/rc1.d 2>/dev/null)
SCRIPT=$SCRIPT$NEW_LINE$(ls -l /etc/rc2.d 2>/dev/null)
SCRIPT=$SCRIPT$NEW_LINE$(ls -l /etc/rc3.d 2>/dev/null)
SCRIPT=$SCRIPT$NEW_LINE$(ls -l /etc/rc4.d 2>/dev/null)
SCRIPT=$SCRIPT$NEW_LINE$(ls -l /etc/rc5.d 2>/dev/null)
SCRIPT=$SCRIPT$NEW_LINE$(ls -l /etc/rc6.d 2>/dev/null)
SCRIPT=$(echo "$SCRIPT" | sed '/합계/d')

CNT=$(echo "$SCRIPT" | wc -l)
SCRIPT_LIST=''
STATUS="양호"

for i in $(seq $CNT)
do
	j=`expr $i - 1`
	SCRIPT_ARRAY[$j]=$(echo "$SCRIPT" | sed -n ${i}p)	
	X_COUNT=$(echo ${SCRIPT_ARRAY[$j]} | tr -cd "x" | wc -m)

	if [ $X_COUNT -eq 0 ] || [ "${SCRIPT_ARRAY[$j]:0:1}" == "d" ]
	then
		continue
	fi
	SCRIPT_LIST=$SCRIPT_LIST$NEW_LINE${SCRIPT_ARRAY[$j]}

	if [ "${SCRIPT_ARRAY[$j]:8:1}" == "w" ]
	then
		STATUS="취약"
	fi
done

SCRIPT_LIST=$(echo "$SCRIPT_LIST" | sed '/^$/d')
echo "$SCRIPT_LIST" >> ${RESULT} 2>&1
echo "[상태]" >> ${RESULT} 2>&1
echo $STATUS >> ${RESULT} 2>&1
echo "[점검 기준 ]" >> ${RESULT} 2>&1
echo "양호: 소유자가 root로 지정되어 있으며 오직 소유자에만 쓰기 권한이 부여되어 있는 경우" >> ${RESULT} 2>&1
echo "취약: 소유자가 root로 지정되어 있지 않으며, 소유자 외에 쓰기 권한이 부여되어 있는 경우" >> ${RESULT} 2>&1
