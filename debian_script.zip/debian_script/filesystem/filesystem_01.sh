#!/bin/bash
LANG=ko_KR.UTF-8

CURRENT_PATH=`dirname $0`

NAME=`basename $0`

ETC_PATH="/etc"

RESULT="$CURRENT_PATH/result_$NAME.txt"

#리눅스 버전 : Debian 7
#계정관리 2.1 사용자 UMASK(User Mask)설정
#주요정보통신기반시설_54p참고

echo "[LDv7-2.01]" > ${RESULT} 2>&1
echo "사용자 UMASK(User Mask)설정(중)" >> ${RESULT} 2>&1
echo "[점검현황]" >> ${RESULT} 2>&1
UMASK=$(umask)
echo $UMASK >> ${RESULT} 2>&1
echo "[상태]" >> ${RESULT} 2>&1
function g_result()
{
	for i in 0 1 2 3
	do
		if [ ${i} -eq 0 ]
		then
			if [ ${1:${i}:1} -gt 0 ]
			then
				STATUS="취약"	
			fi
		fi
		if [ ${i} -eq 1 ]
		then
			if [ ${1:${i}:1} -gt 0 ]
			then
				STATUS="취약"	
			fi
		fi
		if [ ${i} -eq 2 ]
		then
			if [ ${1:${i}:1} -gt 2 ]
			then
				STATUS="취약"	
			fi
		fi
		if [ ${i} -eq 3 ]
		then
			if [ ${1:${i}:1} -gt 2 ]
			then
				STATUS="취약"	
			fi
		fi
done
}
g_result ${UMASK:1:5}
echo $STATUS >> ${RESULT} 2>&1

echo "[점검 기준 ]" >> ${RESULT} 2>&1
echo "양호: UMASK 값이 0022이상일 경우" >> ${RESULT} 2>&1
echo "취약: UMASK 값이 0022이하일 경우" >> ${RESULT} 2>&1


