#!/bin/bash
LANG=ko_KR.UTF-8

CURRENT_PATH=`dirname $0`

NAME=`basename $0`

ETC_PATH="/etc"

RESULT="$CURRENT_PATH/result_$NAME.txt"

#리눅스 버전 : Debian 7
#계정관리 2.6 /etc/profile 파일 s권한 설정(중)


echo "[LDv7-2.06]" > ${RESULT} 2>&1
echo " /etc/profile 파일 권한 설정" >> ${RESULT} 2>&1
echo "[점검현황]" >> ${RESULT} 2>&1
PROFILE=$(ls -l /etc/profile 2>/dev/null)
echo $PROFILE  >> ${RESULT} 2>&1
echo "[상태]" >> ${RESULT} 2>&1
STATUS="양호"
USR=$(ls -l /etc/profile 2>/dev/null | awk -F ' ' "{print \$3}")
PERM=$(ls -l /etc/profile 2>/dev/null | awk -F '' "{print \$9}")
if [ "$USR" != "root" ]
	then
		STATUS="취약"
fi
if [ "$PERM" == "w" ]
	then
		STATUS="취약"
fi
echo $STATUS >> ${RESULT} 2>&1

echo "[점검기준 ]" >> ${RESULT} 2>&1
echo "[양호]" >> ${RESULT} 2>&1
echo "/etc/profile 파일의 권한이 root이고, 타 사용자 쓰기 권한이 없는 경우" >> ${RESULT} 2>&1
echo "[취약]" >> ${RESULT} 2>&1
echo "/etc/profile 파일의 권한이 root가 아니거나, 타 사용자 쓰기 권한이 있는 경우" >> ${RESULT} 2>&1
