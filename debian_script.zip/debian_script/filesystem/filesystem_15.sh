#!/bin/bash
LANG=ko_KR.UTF-8

CURRENT_PATH=`dirname $0`

NAME=`basename $0`

ETC_PATH="/etc"

RESULT="$CURRENT_PATH/result_$NAME.txt"

#리눅스 버전 : Debian 7
#계정관리 2.15 /etc/services 파일 권한 설정(상)
#주요정보통신기반시설_42p참고

echo "[LDv7-2.02]" > ${RESULT} 2>&1
echo "SUID(Set User-ID), SGID(Set Group-ID)설정(상)" >> ${RESULT} 2>&1
echo "[점검현황]" >> ${RESULT} 2>&1
SERVICES=$(ls -l /etc/services 2>/dev/null)
echo $SERVICES >> ${RESULT} 2>&1
echo "[상태]" >> ${RESULT} 2>&1
STATUS="양호"

function get_result()
{
	if [ $(ls -l $1 2>/dev/null | awk -F ' ' "{print \$3}") != "root" ]
	then
		STATUS="취약"
	fi
	for i in {1..3}
		do
				PERM=$(stat -c '%a' $1 | awk -F '' "{print \$"${i}"}")
				if [ ${i} -eq 1 ] 
				then
					if [ ${PERM} -gt 6 ]
					then
						STATUS="취약"
					fi
				fi
				if [ ${i} -eq 2 ] 
				then
					if [ ${PERM} -gt 4 ]
					then
						STATUS="취약"
					fi
				fi
				if [ ${i} -eq 3 ] 
				then
					if [ ${PERM} -gt 4 ]
					then
						STATUS="취약"
					fi
				fi
		done
}

if [ -n "$SERVICES" ]
	then
	get_result "/etc/services"
fi

echo $STATUS >> ${RESULT} 2>&1
echo "[점검 기준 ]" >> ${RESULT} 2>&1
echo "양호: /etc/services 파일의 소유자가 root 이고 , 권한이 644 인 경우" >> ${RESULT} 2>&1
echo "취약: /etc/services 파일의 소유자가 root 가 아니거나 , 권한이 644 가 아닌 경우" >> ${RESULT} 2>&1
