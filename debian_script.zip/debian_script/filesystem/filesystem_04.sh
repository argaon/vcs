#!/bin/bash
LANG=ko_KR.UTF-8

CURRENT_PATH=`dirname $0`

NAME=`basename $0`

ETC_PATH="/etc"

RESULT="$CURRENT_PATH/result_$NAME.txt"

#리눅스 버전 : Debian 7
#계정관리 2.4 history 파일 권한 설정(중)

echo "[LDv7-2.04]" > ${RESULT} 2>&1
echo "history 파일 권한 설정(중)" >> ${RESULT} 2>&1
echo "[점검현황]" >> ${RESULT} 2>&1
find / -type f -name ".bash_history" -exec ls -l {} \; 2>/dev/null >> ${RESULT} 2>&1
echo "[상태]" >> ${RESULT} 2>&1
STATUS="양호"
function get_index()
{
	X=2
	INDEX=''
	while [ $X -lt $1 ]
	do
		INDEX=$INDEX' '$X
		X=`expr $X + 9`	
	done
}

function get_user()
{
	USER=$(find / -type f -name ".bash_history" -exec ls -l {} \; 2>/dev/null)
	ARRAY=(${USER// / })
	get_index ${#ARRAY[@]}
	for i in $INDEX
	do
		if [ ${ARRAY[i]} == "root" ]
		then
			if [ ${ARRAY[i+6]} != "/root/.bash_history" ]
			then
			STATUS="취약"
			fi
		elif [ /home/${ARRAY[i]}/.bash_history != ${ARRAY[i+6]} ]
		then
			STATUS="취약"
		fi
	done
}

PERM=$(find / -type f -name ".bash_history" \( -perm -610 -o -perm -620 -o -perm -630 -o -perm -650 -o -perm -660 -o -perm -670 -o -perm -601 -o -perm -602 -o -perm -603 -o -perm -605 -perm -606 -o -perm 607 -o -perm -700 \) -exec ls -l {} \; 2>/dev/null)
if [ -n "$PERM" ]
then
	STATUS="취약"
else
	get_user
fi

echo $STATUS >> ${RESULT} 2>&1
echo "[점검 기준 ]" >> ${RESULT} 2>&1
echo "양호: /root/.bash_history 파일의 소유자가 root 이고 , 권한이 600 인 경우" >> ${RESULT} 2>&1
echo "취약: /root/.bash_history 파일의 소유자가 root 가 아니거나 , 권한이 600 이 아닌 경우" >> ${RESULT} 2>&1
