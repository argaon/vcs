#!/bin/bash
LANG=ko_KR.UTF-8

CURRENT_PATH=`dirname $0`

NAME=`basename $0`

ETC_PATH="/etc"

RESULT="$CURRENT_PATH/result_$NAME.txt"

#리눅스 버전 : Debian 7

echo "[LDv7-2.10]" > ${RESULT} 2>&1
echo "중요 디렉터리 권한 설정(중)" >> ${RESULT} 2>&1
echo "[점검현황]" >> ${RESULT} 2>&1
echo "중요 디렉토리 권한 확인"  >> ${RESULT} 2>&1
echo "1. /sbin 디렉토리 권한 확인"  >> ${RESULT} 2>&1
ls -l / | awk -F ' ' '$9 ~ /sbin/ {print $0}' 2>/dev/null >> ${RESULT} 2>&1
echo "2. /etc/ 디렉토리 권한 확인"  >> ${RESULT} 2>&1
ls -l / | awk -F ' ' '$9 ~ /etc/ {print $0}' 2>/dev/null >> ${RESULT} 2>&1
echo "3. /bin 디렉토리 권한 확인"  >> ${RESULT} 2>&1
ls -l / | grep bin | grep -v sbin 2>/dev/null >> ${RESULT} 2>&1
echo "4. /usr/bin 디렉토리 권한 확인"  >> ${RESULT} 2>&1
ls -l /usr | grep bin | grep -v sbin 2>/dev/null >> ${RESULT} 2>&1
echo "5. /usr/sbin 디렉토리 권한 확인"  >> ${RESULT} 2>&1
ls -l /usr | awk -F ' ' '$9 ~ /sbin/ {print $0}' 2>/dev/null >> ${RESULT} 2>&1
echo "[상태]" >> ${RESULT} 2>&1
STATUS="양호"

n1='
'
DIR=$(ls -l / | awk -F ' ' '$9 ~ /sbin/ {print $0}' 2>/dev/null)
DIR=$DIR$n1$(ls -l / | awk -F ' ' '$9 ~ /etc/ {print $0}' 2>/dev/null)
DIR=$DIR$n1$(ls -l / | awk -F ' ' '$9 ~ /bin/ {print $0}' 2>/dev/null)
DIR=$DIR$n1$(ls -l /usr | awk -F ' ' '$9 ~ /bin/ {print $0}' 2>/dev/null)
DIR=$DIR$n1$(ls -l /usr | awk -F ' ' '$9 ~ /sbin/ {print $0}' 2>/dev/null)
DIR=$(echo "$DIR" | sort -u | grep -v '^$')

function check_perm()
{	
	if [ $1 == "w" ]
	then
		STATUS="취약"
	fi
}

function check_user()
{
	CNT=$(echo "$DIR" | wc -l)	

	for i in $(seq $CNT)
	do
		DIR_LINE=$(echo "$DIR" | sed -n ${i}p)
		DIR_ARRAY=(${DIR_LINE// / })

		if [ "${DIR_ARRAY[2]}" != "root" ] && [ "${DIR_ARRAY[2]}" != "bin" ]
		then
			STATUS="취약"
		else
			check_perm ${DIR_ARRAY[0]:8:1}
		fi
	done
}

check_user

echo $STATUS >> ${RESULT} 2>&1
echo "[점검기준 ]" >> ${RESULT} 2>&1
echo "양호 : 중요 디렉터리의 권한이 root(또는 bin) 소유이고, 타 사용자 쓰기 권한이 제거된 경우" >> ${RESULT} 2>&1
echo "취약: 중요 디렉터리의 권한이 root(또는 bin) 소유가 아니거나, 타 사용자 쓰기 권한이 제거되지 않은 경우" >> ${RESULT} 2>&1
