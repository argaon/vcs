#!/bin/sh
LANG=ko_KR.UTF-8

CURRENT_PATH=`dirname $0`

NAME=`basename $0`

ETC_PATH="/etc"

RESULT="$CURRENT_PATH/result_$NAME.txt"

echo "[LDv7-2.02]" > ${RESULT} 2>&1
echo "SUID(Set User-ID), SGID(Set Group-ID) 설정" >> ${RESULT} 2>&1

##### 점검 현황 출력#####
echo "[점검 현황]" >> ${RESULT} 2>&1
echo "1. SUID와 SGID 대한 설정이 부여된 파일"  >> ${RESULT} 2>&1
FIND=$(find /sbin/dump \( -perm -4000 -o -perm -2000 \) -exec ls -al {} \; 2>/dev/null)
FIND+=$(find /sbin/restore \( -perm -4000 -o -perm -2000 \) -exec ls -al {} \; 2>/dev/null)
FIND+=$(find /sbin/unix_chkpwd \( -perm -4000 -o -perm -2000 \) -exec ls -al {} \; 2>/dev/null)
FIND+=$(find /usr/bin/at \( -perm -4000 -o -perm -2000 \) -exec ls -al {} \; 2>/dev/null)
FIND+=$(find /usr/bin/lpq \( -perm -4000 -o -perm -2000 \) -exec ls -al {} \; 2>/dev/null)
FIND+=$(find /usr/bin/lpq-lpd \( -perm -4000 -o -perm -2000 \) -exec ls -al {} \; 2>/dev/null)
FIND+=$(find /usr/bin/lpr \( -perm -4000 -o -perm -2000 \) -exec ls -al {} \; 2>/dev/null)
FIND+=$(find /usr/bin/lpr-lpd \( -perm -4000 -o -perm -2000 \) -exec ls -al {} \; 2>/dev/null)
FIND+=$(find /usr/bin/lprm \( -perm -4000 -o -perm -2000 \) -exec ls -al {} \; 2>/dev/null)
FIND+=$(find /usr/bin/lprm-lpd \( -perm -4000 -o -perm -2000 \) -exec ls -al {} \; 2>/dev/null)
FIND+=$(find /usr/bin/newgrp \( -perm -4000 -o -perm -2000 \) -exec ls -al {} \; 2>/dev/null)
FIND+=$(find /usr/sbin/lpc \( -perm -4000 -o -perm -2000 \) -exec ls -al {} \; 2>/dev/null)
FIND+=$(find /usr/sbin/lpc-lpd \( -perm -4000 -o -perm -2000 \) -exec ls -al {} \; 2>/dev/null)
FIND+=$(find /usr/sbin/traceroute \( -perm -4000 -o -perm -2000 \) -exec ls -al {} \; 2>/dev/null)

echo "$FIND" >> ${RESULT} 2>&1

##### 상태 출력#####
echo "[상태]" >> ${RESULT} 2>&1
STATUS="양호" 
if [ -n "$FIND" ]
then
	STATUS="취약"
fi
echo $STATUS >> ${RESULT} 2>&1

##### 점검 기준 출력 #####
echo "[점검 기준]" >> ${RESULT} 2>&1
echo "[양호]" >> ${RESULT} 2>&1
echo "주요 파일의 권한에 SUID와 SGID 대한 설정이 부여되어 있지 않은 경우" >> ${RESULT} 2>&1
echo "[취약]" >> ${RESULT} 2>&1
echo "주요 파일의 권한에 SUID와 SGID 대한 설정이 부여되어 있는 경우" >> ${RESULT} 2>&1



