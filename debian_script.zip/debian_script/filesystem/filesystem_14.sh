#!/bin/bash
LANG=ko_KR.UTF-8

CURRENT_PATH=`dirname $0`

NAME=`basename $0`

ETC_PATH="/etc"

RESULT="$CURRENT_PATH/result_$NAME.txt"

#리눅스 버전 : Debian 7
#계정관리 2.14 NFS(Network File System) 접근제어 파일 권한 설정(상)

echo "[LDv7-2.14]" > ${RESULT} 2>&1
echo "2.14 NFS(Network File System) 접근제어 파일 권한 설정(상)" >> ${RESULT} 2>&1
echo "[점검현황]" >> ${RESULT} 2>&1
EXPORT=$(ls -l /etc/export 2>/dev/null)
echo $EXPORT >> ${RESULT} 2>&1
echo "[상태]" >> ${RESULT} 2>&1
STATUS="양호"

function get_result()
{
	USR=$(ls -l $1 2>/dev/null | awk -F ' ' "{print \$3}")
	PERM=$(ls -l $1 2>/dev/null | awk -F '' "{print \$9}")
	if [ "$USR" != "root" ]
		then
			STATUS="취약"
	fi
	if [ "$PERM" == "w" ]
		then
			STATUS="취약"
	fi
}
if [ -n "$EXPORT" ]
        then
        get_result "/etc/export"
fi

echo $STATUS >> ${RESULT} 2>&1
echo "[점검기준 ]" >> ${RESULT} 2>&1
echo "양호: NFS 서비스를 사용하지 않거나 , 사용 시 everyone 공유를 제한한 경우" >> ${RESULT} 2>&1
echo "취약: NFS 서비스를 사용하고 있고 , everyone 공유를 제한하지 않은 경우" >> ${RESULT} 2>&1
