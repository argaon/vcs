#!/bin/bash
LANG=ko_KR.UTF-8

CURRENT_PATH=`dirname $0`

NAME=`basename $0`

ETC_PATH="/etc"

RESULT="$CURRENT_PATH/result_$NAME.txt"

#리눅스 버전 : Debian 7
#계정관리 2.8 /etc/issue 파일 권한 설정(중)

echo "[LDv7-2.08]" > ${RESULT} 2>&1
echo "/etc/issue 파일 권한 설정(중)" >> ${RESULT} 2>&1
echo "[점검현황]" >> ${RESULT} 2>&1
PROFILE=$(ls -l /etc/issue 2>/dev/null)
echo $PROFILE >> ${RESULT} 2>&1
echo "[상태]" >> ${RESULT} 2>&1
STATUS="양호"
USR=$(ls -l /etc/issue 2>/dev/null | awk -F ' ' "{print \$3}")
PERM=$(ls -l /etc/issue 2>/dev/null | awk -F '' "{print \$9}")
if [ "$USR" != "root" ]
	then
		STATUS="취약"
fi
if [ "$PERM" == "w" ]
	then
		STATUS="취약"
fi
echo $STATUS >> ${RESULT} 2>&1
echo "[점검기준 ]" >> ${RESULT} 2>&1
echo "양호: /etc/issue 파일의 소유자가 root 이고 , 권한이 600 인 경우" >> ${RESULT} 2>&1
echo "취약: /etc/issue 파일의 소유자가 root 가 아니거나 , 권한이 600 이 아닌 경우" >> ${RESULT} 2>&1
