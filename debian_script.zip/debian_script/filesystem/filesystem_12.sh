#!/bin/bash
LANG=ko_KR.UTF-8

CURRENT_PATH=`dirname $0`

NAME=`basename $0`

RESULT="$CURRENT_PATH/result_$NAME.txt"

#리눅스 버전 : Debian 7
#계정관리 2.12 FTP(File Transfer Protocol) 접근제어 파일 권한 설정(상)
#102p
echo "[LDv7-2.12]" > ${RESULT} 2>&1
echo "FTP(File Transfer Protocol) 접근제어 파일 권한 설정(상)" >> ${RESULT} 2>&1
echo "[점검현황]" >> ${RESULT} 2>&1
echo "1. FTP 접근제어 파일(/etc/vsftpd/ftpusers) 권한"  >> ${RESULT} 2>&1
ETC=$(ls -l /etc/vsftpd/ftpusers 2>/dev/null)
echo $ETC >> ${RESULT} 2>&1
echo "2. FTP 접근제어 파일(/etc/vsftpd/user_list) 권한"  >> ${RESULT} 2>&1
FTPD=$(ls -l /etc/vsftpd/user_list 2>/dev/null)
echo $FTPD >> ${RESULT} 2>&1
echo "[상태]" >> ${RESULT} 2>&1
STATUS="양호"

function get_result()
{
	USR=$(ls -l $1 2>/dev/null | awk -F ' ' "{print \$3}")
	PERM=$(ls -l $1 2>/dev/null | awk -F '' "{print \$9}")
	if [ "$USR" != "root" ]
		then
			STATUS="취약"
	fi
	if [ "$PERM" == "w" ]
		then
			STATUS="취약"
	fi
}
if [ -n "$ETC" ]
        then
        get_result "/etc/ftpusers"
fi
if [ -n "$FTPD" ]
        then
        get_result "/etc/ftpd/ftpusers"
fi

echo $STATUS >> ${RESULT} 2>&1
echo "[점검 기준 ]" >> ${RESULT} 2>&1
echo "양호: ftpusers 파일의 소유자가 root 이고 , 권한이 640 이하인 경우" >> ${RESULT} 2>&1
echo "취약: ftpusers 파일의 소유자가 root 가 아니거나 , 권한이 640 이하가 아닌 경우" >> ${RESULT} 2>&1
