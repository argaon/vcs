#!/bin/bash
LANG=ko_KR.UTF-8

CURRENT_PATH=`dirname $0`

NAME=`basename $0`

ETC_PATH="/etc"

RESULT="$CURRENT_PATH/result_$NAME.txt"

#리눅스 버전 : Debian 7
#계정관리 2.7 /etc/hosts 파일 권한 설정(중)
#근거 39p

echo "[LDv7-2.07]" > ${RESULT} 2>&1
echo "/etc/hosts 파일 권한 설정(중)" >> ${RESULT} 2>&1
echo "[점검현황]" >> ${RESULT} 2>&1
HOSTS=$(ls -l /etc/hosts 2>/dev/null)
echo $HOSTS  >> ${RESULT} 2>&1
echo "[상태]" >> ${RESULT} 2>&1
STATUS="양호"

function get_result()
{
	if [ $(ls -l $1 2>/dev/null | awk -F ' ' "{print \$3}") != "root" ]
	then
		STATUS="취약"
	fi
	for i in {1..3}
		do
				PERM=$(stat -c '%a' $1 | awk -F '' "{print \$"${i}"}")
				if [ ${i} -eq 1 ] 
				then
					if [ ${PERM} -ne 6 ]
					then
						RESULT="취약"
					fi
				fi
				if [ ${i} -eq 2 ] 
				then
					if [ ${PERM} -ne 0 ]
					then
						STATUS="취약"
					fi
				fi
				if [ ${i} -eq 3 ] 
				then
					if [ ${PERM} -ne 0 ]
					then
						STATUS="취약"
					fi
				fi
		done
}
get_result "/etc/hosts"

echo $STATUS >> ${RESULT} 2>&1
echo "[점검기준 ]" >> ${RESULT} 2>&1
echo "양호: /etc/hosts 파일의 소유자가 root 이고 , 권한이 600 인 경우" >> ${RESULT} 2>&1
echo "취약: /etc/hosts 파일의 소유자가 root 가 아니거나 , 권한이 600 이 아닌 경우" >> ${RESULT} 2>&1
