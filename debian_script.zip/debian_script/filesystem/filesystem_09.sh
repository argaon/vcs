#!/bin/bash
LANG=ko_KR.UTF-8

CURRENT_PATH=`dirname $0`

NAME=`basename $0`

ETC_PATH="/etc"

RESULT="$CURRENT_PATH/result_$NAME.txt"

#리눅스 버전 : Debian 7
#계정관리 2.9 사용자 홈디렉토리 및 파일관리(중)
#56p

echo "[LDv7-2.09]" > ${RESULT} 2>&1
echo "사용자 홈디렉토리 및 파일관리(중)" >> ${RESULT} 2>&1
echo "[점검현황]" >> ${RESULT} 2>&1
USER=$(ls -l /home | sed '1d' 2>/dev/null)
echo "$USER" >> ${RESULT} 2>&1
ROOT=$(ls -l / | awk -F ' ' '$9 ~ /root/ {print $0}' 2>/dev/null)
echo "$ROOT" >> ${RESULT} 2>&1
echo "[상태]" >> ${RESULT} 2>&1
STATUS="양호"

function check_perm()
{	
	if [ $1 == "w" ]
	then
		STATUS="취약"
	fi
}

function check_root()
{
	ROOT_ARRAY=(${ROOT// / })

	if [ ${ROOT_ARRAY[2]} != ${ROOT_ARRAY[8]} ]
	then
		STATUS="취약"
	else
		check_perm ${ROOT_ARRAY[0]:8:1}
	fi
}

function check_user()
{
	CNT=$(echo "$USER" | wc -l)	

	for i in $(seq $CNT)
	do
		USER_LINE=$(echo "$USER" | sed -n ${i}p)
		USER_ARRAY=(${USER_LINE// / })
		
	if [ ${USER_ARRAY[2]} != ${USER_ARRAY[8]} ]
		then
			STATUS="취약"
		else
			check_perm ${USER_ARRAY[0]:8:1}
		fi
	done
}

check_root
check_user

echo $STATUS >> ${RESULT} 2>&1
echo "[점검기준 ]" >> ${RESULT} 2>&1
echo "양호: 홈 디렉터리 소유자가 해당 계정이고 , 일반 사용자 쓰기 권한이 제거된 경우" >> ${RESULT} 2>&1
echo "취약: 홈 디렉터리 소유자가 해당 계정이 아니고 , 일반 사용자 쓰기 권한이 부여된 경우" >> ${RESULT} 2>&1
