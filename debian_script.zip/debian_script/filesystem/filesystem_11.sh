#!/bin/bash
LANG=ko_KR.UTF-8

CURRENT_PATH=`dirname $0`

NAME=`basename $0`

ETC_PATH="/etc"

RESULT="$CURRENT_PATH/result_$NAME.txt"

#리눅스 버전 : Debian 7
#계정관리 2.11 PATH 환경변수 설정(중)

echo "[LDv7-2.11]" > ${RESULT} 2>&1
echo "PATH 환경변수 설정(중)" >> ${RESULT} 2>&1
echo "[점검현황]" >> ${RESULT} 2>&1
echo $PATH >> ${RESULT} 2>&1
echo "[상태]" >> ${RESULT} 2>&1
STATUS="양호"
ENV_PATH=$(echo $PATH)

if [[ "$ENV_PATH" =~ "." ]]
then
	STATUS="취약"
fi

echo $STATUS >> ${RESULT} 2>&1
echo "[점검기준 ]" >> ${RESULT} 2>&1
echo "양호: PATH 환경변수에 “.” 이 맨 앞이나 중간에 포함되지 않은 경우" >> ${RESULT} 2>&1
echo "취약: PATH 환경변수에 “.” 이 맨 앞이나 중간에 포함되어 있는 경우" >> ${RESULT} 2>&1
