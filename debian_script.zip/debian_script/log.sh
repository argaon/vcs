#!/bin/bash

RESULT="$(dirname "$0")/result_$(date '+%y-%m-%d').txt"

echo "====================================================" >> ${RESULT} 
echo "==================== 4. 로그 관리 ===================" >> ${RESULT}
echo "====================================================" >> ${RESULT}

for FILE_COUNT in {01..02}
do
	./debian_script/log/log_${FILE_COUNT}.sh 2>/dev/null
	echo ./debian_script/log/log_${FILE_COUNT}.sh 2>/dev/null
	cat ./debian_script/log/result_log_${FILE_COUNT}.sh.txt >> ${RESULT} 2>/dev/null
	echo "" >> ${RESULT}
	if [ $FILE_COUNT -eq 02 ]
	then
		continue
	fi
	echo "****************************************************" >> ${RESULT}
	echo "" >> ${RESULT}
done
