#!/bin/bash

RESULT="$(dirname "$0")/result_$(date '+%y-%m-%d').txt"

echo "====================================================" >> ${RESULT} 
echo "=================== 6. 보안 패치 ====================" >> ${RESULT}
echo "====================================================" >> ${RESULT}

for FILE_COUNT in {01..01}
do
	patch/patch_${FILE_COUNT}.sh 2>/dev/null
	echo patch/patch_${FILE_COUNT}.sh 2>/dev/null
	cat patch/result_patch_${FILE_COUNT}.sh.txt >> ${RESULT} 2>/dev/null
	echo "" >> ${RESULT}
	if [ $FILE_COUNT -eq 01 ]
	then
		continue
	fi
	echo "****************************************************" >> ${RESULT}
	echo "" >> ${RESULT}
done
