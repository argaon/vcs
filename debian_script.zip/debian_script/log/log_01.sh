#!/bin/bash
LANG=ko_KR.UTF-8

CURRENT_PATH=`dirname $0`

NAME=`basename $0`

ETC_PATH="/etc"

RESULT="$CURRENT_PATH/result_$NAME.txt"

#리눅스 버전 : Debian 7
#계정관리 4.1 시스템 로그 설정(상)
#41p
echo "[LDv7-4.1]" > ${RESULT} 2>&1
echo "4.1 시스템 로그 설정(상)" >> ${RESULT} 2>&1
echo "[점검현황]" >> ${RESULT} 2>&1
cat /etc/rsyslog.conf >> ${RESULT} 2>&1
echo "수동 점검 필요">> ${RESULT} 2>&1
echo "[상태]" >> ${RESULT} 2>&1
echo "취약" >> ${RESULT} 2>&1
echo "[점검기준 ]" >> ${RESULT} 2>&1
echo "양호: 로그 기록 정책이 정책에 따라 설정되어 수립되어 있는 경우" >> ${RESULT} 2>&1
echo "취약: 로그 기록 정책 미수립 , 또는 , 정책에 따라 설정되어 있지 않은 경우" >> ${RESULT} 2>&1
echo "info 및 alert 등에 대해 적절히 기록하도록 설정되어 있는지 점검" >>${RESULT} 2>&1

