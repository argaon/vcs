#!/bin/bash
LANG=ko_KR.UTF-8

CURRENT_PATH=`dirname $0`

NAME=`basename $0`

ETC_PATH="/etc"

RESULT="$CURRENT_PATH/result_$NAME.txt"

#리눅스 버전 : Debian 7
#계정관리 5.4 DNS(Domain Name Service) 보안 설정(중)

echo "[LDv7-5.7]" > ${RESULT} 2>&1
echo "5.7 SSH(Secure Shell) 버전 취약성 (중)" >> ${RESULT} 2>&1
echo "[점검현황]" >> ${RESULT} 2>&1
echo "1. SSH서비스 구동 여부" >> ${RESULT} 2>&1
SERVICE=$(ps -ef | grep sshd | grep -v "grep")
echo "$SERVICE" >> ${RESULT} 2>&1
echo "2. SSH 버전 확인" >> ${RESULT} 2>&1
ERSION=$(apt-cache show openssh-server | grep "Version")
echo "$VERSION" >> ${RESULT} 2>&1

echo "[상태]" >> ${RESULT} 2>&1
STATUS="양호"

VERSION=$(echo "$VERSION" | awk -F " " '{ print $2 }')
VERSION=${VERSION:0:3}
UPGRADE="7.7"
if [ -n "$SERVICE" ]
then
	for i in 0 1 2
	do
		if [ ${VERSION:$i:1} -lt ${UPGRADE:$i:1} ]
		then
			STATUS="취약"
		fi
	done
fi

echo "$STATUS" >> ${RESULT} 2>&1
echo "[점검 기준 ]" >> ${RESULT} 2>&1
echo "양호: SSH서비스 필요 시 최신 버전(현재 기준 OpenSSH 7.7)으로 업그레이드 한 경우" >> ${RESULT} 2>&1
echo "취약: SSH서비스 필요 시 최신 버전(현재 기준 OpenSSH 7.7)으로 업그레이드 하지 않은 경우" >> ${RESULT} 2>&1

#ps -ef | grep sshd
#
#http://armadablog.tistory.com/91
