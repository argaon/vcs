#!/bin/bash
LANG=ko_KR.UTF-8

CURRENT_PATH=`dirname $0`

NAME=`basename $0`

ETC_PATH="/etc"

RESULT="$CURRENT_PATH/result_$NAME.txt"

#리눅스 버전 : Debian 7
#응용프로그램설정 5.6 samba 버전 취약성 (상)
#ps -ef |grep smb
#
#http://armadablog.tistory.com/90
echo "[LDv7-5.6]" > ${RESULT} 2>&1
echo "5.6 samba 버전 취약성 (상)" >> ${RESULT} 2>&1
echo "[점검현황]" >> ${RESULT} 2>&1
echo "1. samba 서비스 구동 여부" >> ${RESULT} 2>&1
SERVICE=$(ps -ef | grep smb | grep -v grep)
echo "$SERVICE" >> ${RESULT} 2>&1
echo "2. samba 버전 확인" >> ${RESULT} 2>&1
VERSION=$(smbd --version)
echo "$VERSION" >> ${RESULT} 2>&1
echo "[상태]" >> ${RESULT} 2>&1
STATUS="양호"

VERSION=${VERSION:8}
UPGRADE="4.8.2"

if [ -n "$SERVICE" ]
then
	for i in 0 2 4
	do
		if [ ${VERSION:$i:1} -lt ${UPGRADE:$i:1} ]
		then
			STATUS="취약"
		fi
	done
fi

echo "$STATUS">> ${RESULT} 2>&1
echo "[점검 기준 ]" >> ${RESULT} 2>&1
echo "양호: samba서비스 필요 시 최신 버전(현재 기준 samba-4.8.2)으로 업그레이드 한 경우" >> ${RESULT} 2>&1
echo "취약: samba서비스 필요 시 최신 버전(현재 기준 samba-4.8.2)으로 업그레이드 하지 않은 경우" >> ${RESULT} 2>&1


