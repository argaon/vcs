#!/bin/bash
LANG=ko_KR.UTF-8

CURRENT_PATH=`dirname $0`

NAME=`basename $0`

ETC_PATH="/etc"

RESULT="$CURRENT_PATH/result_$NAME.txt"

#리눅스 버전 : Debian 7
#계정관리 5.2 SNMP(Simple Network Management Protocol) 서비스 설정(상)

echo "[LDv7-5.2]" > ${RESULT} 2>&1
echo "5.2 SNMP(Simple Network Management Protocol) 서비스 설정(상)" >> ${RESULT} 2>&1
echo "[점검현황]" >> ${RESULT} 2>&1
echo "SNMP Community String 설정 확인" 
function get_community()
{
	COMMUNITY=$(egrep -r "com2sec\snotConfigUser\s+default" $1)
}

if [ -e "/etc/snmp/snmpd.conf" ]
then
	get_community "/etc/snmp/snmpd.conf"
elif [ -e "/etc/snmpd.conf" ]
then
	get_community "/etc/snmpd.conf"
elif [ -e "/etc/snmp/conf/snmpd.conf" ]
then
	get_community "/etc/snmp/conf/snmpd.conf"
fi

COMMUNITY=$(echo "$COMMUNITY" | sed '/#/d')
echo "$COMMUNITY" >> ${RESULT} 2>&1
echo "[상태]" >> ${RESULT} 2>&1
STATUS="양호"

COMMUNITY=$(echo "$COMMUNITY" | tr -d ' ')

if [ ${COMMUNITY:27} = "public" ]
then
	STATUS="취약"
fi
if [ ${COMMUNITY:27} = "private" ]
then
	STATUS="취약"
fi
echo "$STATUS" >> ${RESULT} 2>&1
echo "[점검 기준 ]" >> ${RESULT} 2>&1
echo "양호: SNMP Community 이름이 public, private 이 아닌 경우" >> ${RESULT} 2>&1
echo "취약: SNMP Community 이름이 public, private 인 경우" >> ${RESULT} 2>&1
