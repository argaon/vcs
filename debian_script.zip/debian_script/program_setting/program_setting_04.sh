#!/bin/sh
LANG=ko_KR.UTF-8

CURRENT_PATH=`dirname $0`

NAME=`basename $0`

ETC_PATH="/etc"

RESULT="$CURRENT_PATH/result_$NAME.txt"

#리눅스 버전 : Debian 7
#계정관리 5.4 DNS(Domain Name Service) 보안 설정(중)

echo "[LDv7-5.4]" > ${RESULT} 2>&1
echo "5.4 DNS(Domain Name Service) 보안 설정(중)" >> ${RESULT} 2>&1
echo "[점검현황]" >> ${RESULT} 2>&1
echo "1. DNS 서비스 사용 여부" >> ${RESULT} 2>&1
SERVICE=$(ps -ef | grep named | grep -v "grep")
echo "$SERVICE" >> ${RESULT} 2>&1
echo "2. DNS Zone Transfer 설정 확인" >> ${RESULT} 2>&1
if [ -e "/etc/bind/named.conf" ]
then
	echo "2-1. BIND8의 named.conf 파일의 내용" >> ${RESULT} 2>&1
	CONF=$(cat /etc/bind/named.conf | grep 'allow-transfer' 2>/dev/null)
	echo "$CONF" >> ${RESULT} 2>&1
elif [ -e "/etc/bind/named.boot" ]
then
	echo "2-1. BIND4.9의 named.boot 파일의 내용" >> ${RESULT} 2>&1
	BOOT=$(cat /etc/bind/named.boot | grep 'allow-transfer' 2>/dev/null)
	echo "$BOOT" >> ${RESULT} 2>&1
fi
echo "[상태]" >> ${RESULT} 2>&1
STATUS="양호"

if [ -n "$SERVICE" ]
then
	if [ -e "/etc/bind/named.conf" ]
	then
		if [ -z "$CONF" ]
		then
			RESULT="취약"
		fi
	elif [ -e "/etc/bind/named.boot" ]
	then
		if [ -z "$BOOT" ]
		then
			STATUS="취약"
		fi
	fi
fi
echo $STATUS >> ${RESULT} 2>&1
echo "[점검기준 ]" >> ${RESULT} 2>&1
echo "양호: SMTP 서비스 미사용 또는 , noexpn, novrfy 옵션이 설정되어 있는 경우" >> ${RESULT} 2>&1
echo "취약: SMTP 서비스를 사용하고 , noexpn, novrfy 옵션이 설정되어 있지 않는 경우" >> ${RESULT} 2>&1
