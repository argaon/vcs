#!/bin/bash
LANG=ko_KR.UTF-8

CURRENT_PATH=`dirname $0`

NAME=`basename $0`

ETC_PATH="/etc"

RESULT="$CURRENT_PATH/result_$NAME.txt"

#리눅스 버전 : Debian 7
#계정관리 5.4 DNS(Domain Name Service) 보안 설정(중)
#https://help.ubuntu.com/community/Swat 참고
echo "[LDv7-5.5]" > ${RESULT} 2>&1
echo "5.5 SWAT(Samba Web Administration Tool) 보안 설정" >> ${RESULT} 2>&1
echo "[점검현황]" >> ${RESULT} 2>&1
echo "SWAT 서비스 구동 여부" >> ${RESULT} 2>&1
echo "/etc/xinetd.d/swat파일 내용" >> ${RESULT} 2>&1
SWAT=$(cat /etc/xinetd.d/swat 2>/dev/null)
if [ -n "$SWAT" ]
then
	cat /etc/xinetd.d/swat | grep "disable" >> ${RESULT} 2>&1
fi
echo "[상태]" >> ${RESULT} 2>&1
STATUS="양호"

SWAT=$(echo $SWAT | sed 's/ //g')
if [[ "$SWAT" =~ "disable=no" ]]
then
	STATUS="취약"

fi

echo "$STATUS">> ${RESULT} 2>&1
echo "[점검 기준 ]" >> ${RESULT} 2>&1
echo "양호: SWAT서비스 불필요시 구동 중지하거나 SWAT서비스 필요시 침입차단시스템 관리자에게 연락하여 901번 포트를 필터링 한 경우" >> ${RESULT} 2>&1
echo "취약: SWAT서비스 불필요시 구동 중지를 하지 않았거나 SWAT서비스 필요시 침입차단시스템 관리자에게 연락하여 901번 포트를 필터링 하지 않은 경우" >> ${RESULT} 2>&1

