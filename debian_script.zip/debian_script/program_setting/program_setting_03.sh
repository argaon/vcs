#!/bin/sh
LANG=ko_KR.UTF-8

CURRENT_PATH=`dirname $0`

NAME=`basename $0`

ETC_PATH="/etc"

RESULT="$CURRENT_PATH/result_$NAME.txt"

#리눅스 버전 : Debian 7
#계정관리 5.3 SMTP(Sned Mail Transfer Protocol) 서비스 설정(중)

echo "[LDv7-5.3]" > ${RESULT} 2>&1
echo "5.3 SMTP(Sned Mail Transfer Protocol) 서비스 설정(중)" >> ${RESULT} 2>&1
echo "[점검현황]" >> ${RESULT} 2>&1
SERVICE=$(ps -ef | grep sendmail | grep -v "grep")
echo "$SERVICE" >> ${RESULT} 2>&1
echo "[상태]" >> ${RESULT} 2>&1
STATUS="양호"

if [ -n "$SERVICE" ]
then
	STATUS="취약"
fi
echo $STATUS >> ${RESULT} 2>&1
echo "[점검 기준 ]" >> ${RESULT} 2>&1
echo "양호: SMTP 서비스 미사용 또는 , noexpn, novrfy 옵션이 설정되어 있는 경우" >> ${RESULT} 2>&1
echo "취약: SMTP 서비스를 사용하고 , noexpn, novrfy 옵션이 설정되어 있지 않는 경우" >> ${RESULT} 2>&1
