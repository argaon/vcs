#!/bin/sh
LANG=ko_KR.UTF-8

CURRENT_PATH=`dirname $0`

NAME=`basename $0`

ETC_PATH="/etc"

RESULT="$CURRENT_PATH/result_$NAME.txt"

#리눅스 버전 : Debian 7
#계정관리 5.8 DNS(Domain Name Service) 보안 설정(중)

echo "[LDv7-5.8]" > ${RESULT} 2>&1
echo "5.8 x-server 접속 제한 설정 (상)" >> ${RESULT} 2>&1
echo "[점검현황]" >> ${RESULT} 2>&1
echo "" >> ${RESULT} 2>&1
echo "[상태]" >> ${RESULT} 2>&1
echo "양호" >> ${RESULT} 2>&1
echo "[점검 기준 ]" >> ${RESULT} 2>&1
echo "양호: 모든 사용자의 자동 실행파일에서 xhost+ 같은 명령이 제거되어 있는 경우" >> ${RESULT} 2>&1
echo "취약: 모든 사용자의 자동 실행파일에서 xhost+ 같은 명령이 제거되어 있지 않는 경우" >> ${RESULT} 2>&1

#ps -ef | grep sshd
#
#http://armadablog.tistory.com/91
