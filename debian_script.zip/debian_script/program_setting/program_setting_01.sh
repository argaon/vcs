#!/bin/bash
LANG=ko_KR.UTF-8

CURRENT_PATH=`dirname $0`

NAME=`basename $0`

ETC_PATH="/etc"

RESULT="$CURRENT_PATH/result_$NAME.txt"

#리눅스 버전 : Debian 7
#계정관리 5.1 FTP(File Transfer Protocol) 서비스 사용자 제한(상)
#61p
echo "[LDv7-5.1]" > ${RESULT} 2>&1
echo "5.1 FTP(File Transfer Protocol) 서비스 사용자 제한(상)" >> ${RESULT} 2>&1
echo "[점검현황]" >> ${RESULT} 2>&1
echo "1-1. ftp또는 anonymous 계정의 존재 여부" >> ${RESULT} 2>&1
DEFAULT=$(awk -F ":" '$1=="anonymous" {print $0}' /etc/passwd)
DEFAULT=$DEFAULT"
"$(awk -F ":" '$1=="ftp" {print $0}' /etc/passwd)
echo "$DEFAULT" >> ${RESULT} 2>&1

echo "2. ProFTP 를 사용하는 경우" >> ${RESULT} 2>&1
echo "2-1. ftp또는 anonymous 계정의 존재 여부" >> ${RESULT} 2>&1
PROFTP=$(awk -F ":" '$1=="ftp" {print $0}' /etc/passwd)
echo "$PROFTP" >> ${RESULT} 2>&1

echo "3. vsFTP를 사용하는 경우" >> ${RESULT} 2>&1
if [ -e "/etc/vsftpd/vsftpd.conf" ]
then
	echo "3-1. /etc/vsftpd/vsftpd.conf 파일 설정" >> ${RESULT} 2>&1
	VSFTP=$(sed -n '/anonymous_enable=[YES|NO]/p' /etc/vsftpd/vsftpd.conf)
elif [ -e "/etc/vsftpd.conf" ]
then
	echo "3-1. /etc/vsftpd.conf 파일 설정" >> ${RESULT} 2>&1
	VSFTP=$(sed -n '/anonymous_enable=[YES|NO]/p' /etc/vsftpd.conf)
fi
echo "$VSFTP" >> ${RESULT} 2>&1
echo "[상태]" >> ${RESULT} 2>&1
STATUS="양호"
#Default FTP 점점"
DEFAULT=$(echo "$DEFAULT" | tr -d ' ')
if [ -n "$DEFAULT" ]
then
	STATUS="취약"
fi

#ProFTP 점점"
DEFAULT=$(echo "$PROFTP" | tr -d ' ')
if [ -n "$PROFTP" ]
then
	STATUS="취약"
fi

#vsFTP 점점"
if [ "$VSFTP" == "anonymous_enable=YES" ]
then
	STATUS="취약"
fi
echo "$STATUS" >> ${RESULT} 2>&1

echo "[점검기준 ]" >> ${RESULT} 2>&1
echo "양호: Anonymous FTP ( 익명 ftp) 접속을 차단한 경우" >> ${RESULT} 2>&1
echo "취약: Anonymous FTP ( 익명 ftp) 접속을 차단하지 않은 경우" >> ${RESULT} 2>&1
