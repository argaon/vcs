#!/bin/bash

RESULT="$(dirname "$0")/result_$(date '+%y-%m-%d').txt"

echo "====================================================" >> ${RESULT} 
echo "================= 5. 주요 응용 설정  ==================" >> ${RESULT}
echo "====================================================" >> ${RESULT}

for FILE_COUNT in {01..08}
do
	./debian_script/program_setting/program_setting_${FILE_COUNT}.sh 2>/dev/null
	echo ./debian_script/program_setting/program_setting_${FILE_COUNT}.sh 2>/dev/null
	cat ./debian_script/program_setting/result_program_setting_${FILE_COUNT}.sh.txt >> ${RESULT} 2>/dev/null
	echo "" >> ${RESULT}
	if [ $FILE_COUNT -eq 08 ]
	then
		continue
	fi
	echo "****************************************************" >> ${RESULT}
	echo "" >> ${RESULT}
done
