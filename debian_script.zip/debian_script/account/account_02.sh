#!/bin/sh
LANG=ko_KR.UTF-8

CURRENT_PATH=`dirname $0`

NAME=`basename $0`

ETC_PATH="/etc"
PASSWD="/etc/passwd"

RESULT="$CURRENT_PATH/result_$NAME.txt"
ROOTUID="root:x:0:0:root:/root:/bin/bash"


#리눅스 버전 : Debian 7
#계정관리 1.2	 일반계정 root 권한 관리
#주요정보통신기반시설_14p참고

echo "[LDv7-1.02]" > ${RESULT} 2>&1
echo "일반계정 root 권한 관리" >> ${RESULT} 2>&1
echo "[점검현황]" >> ${RESULT} 2>&1
STATUS=$(awk -F : "\$3==0 {print}" /etc/passwd)
if [ -z "$STATUS" ]
then
	echo "UID가 0인 계정이 없음" >> ${RESULT} 2>&1
else
	echo "$STATUS" >> ${RESULT} 2>&1
fi
echo "[상태]" >> ${RESULT} 2>&1

if [ $STATUS = $ROOTUID ]
then
	echo "양호" >> ${RESULT} 2>&1
else
	echo "취약" >> ${RESULT} 2>&1
fi
echo "[점검 기준]" >> ${RESULT} 2>&1
echo "양호: root 계정과 동일한 UID 를 갖는 계정이 존재하지 않는 경우" >> ${RESULT} 2>&1
echo "취약: root 계정과 동일한 UID 를 갖는 계정이 존재하는 경우" >> ${RESULT} 2>&1
