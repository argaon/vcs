#!/bin/sh
LANG=ko_KR.UTF-8

CURRENT_PATH=`dirname $0`

NAME=`basename $0`

ETC_PATH="/etc"


RESULT="$CURRENT_PATH/result_$NAME.txt"

#리눅스 버전 : Debian 7
#계정관리 1.3 /etc/passwd 파일 권한 설정
#주요정보통신기반시설_36p참고

echo "[LDv7-1.03]" > ${RESULT} 2>&1
echo "/etc/passwd 파일 권한 설정" >> ${RESULT} 2>&1
echo "[점검현황]" >> ${RESULT} 2>&1
echo "****/etc/passwd 파일 소유자 및 권한 설정****" >> ${RESULT} 2>&1
ls -l /etc/passwd >> ${RESULT} 2>&1
echo "[상태]" >> ${RESULT} 2>&1
# USER 검사
STATUS="양호"
USER=$(ls -l /etc/passwd |awk -F ' ' "{print \$3}")
if [ "$USER" != "root" ]
then
	STATUS="취약"
fi

if [ "$STATUS" = "양호" ]
then

	# PERM 검사
	PERM=0
	for i in 2 3 4 5 6 7 8 9 10
	do
		NUM=$(ls -l /etc/passwd |awk -F '' "{print \$"${i}"}" | tr "r" "4" | tr "w" "2" | tr "x" "1" | tr "-" "0")
		PERM=`expr $PERM + $NUM`

		if [ ${i} -eq 4 ] 
		then
			if [ ${PERM} -gt 6 ]
			then
				STATUS="취약"
			fi
		PERM=0
		fi

		if [ ${i} -eq 7 -o ${i} -eq 10 ] 
		then
			if [ ${PERM} -gt 4 ]
				then
				STATUS="취약"
			fi
		PERM=0
		fi
	done

fi

echo $STATUS >> ${RESULT} 2>&1
echo "[점검 기준]" >> ${RESULT} 2>&1
echo "[양호]" >> ${RESULT} 2>&1
echo "/etc/passwd 파일의 소유자가 root이고, 권한이 644 이하인 경우" >> ${RESULT} 2>&1

echo "[취약]" >> ${RESULT} 2>&1
echo "/etc/passwd 파일의 소유자가 root가 아니거나, 권한이 644 이하가 아닌 경우" >> ${RESULT} 2>&1

