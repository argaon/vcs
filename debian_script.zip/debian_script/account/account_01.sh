#!/bin/sh
LANG=ko_KR.UTF-8

CURRENT_PATH=`dirname $0`

NAME=`basename $0`

ETC_PATH="/etc"

RESULT="$CURRENT_PATH/result_$NAME.txt"
ACCOUNT="lp|uucp|nuucp";

#리눅스 버전 : Debian 7
#계정관리 1.1 Default 계정 삭제
#주요정보통신기반시설_25p참고

#ETC 파일 체크 #

#/etc에서 file_passwd.txt 파일을 출력한다.

if [ -z ${PATH_PASSWD+x} ]; then
	PATH_PASSWD=/etc/passwd
fi

if [ ! -r ${ETC_PATH}/file_passwd.txt ]; then
	cat ${PATH_PASSWD} > ${ETC_PATH}/file_passwd.txt
fi
echo "[LDv7-1.01]" > ${RESULT} 2>&1
echo "Default 계정 삭제 (하)" >> ${RESULT} 2>&1
echo "[점검현황]" >> ${RESULT} 2>&1
echo "**** 전체 계정 목록 ****"  >> ${RESULT} 2>&1

cat ${ETC_PATH}/file_passwd.txt | awk -F: '{print $1}' >> ${RESULT} 2>&1

echo "**** 불필요한 계정 점검 ****" >> ${RESULT} 2>&1
cat ${PATH_PASSWD} | egrep "lp|uucp|nuucp" | awk -F: '{print $1}' >> ${RESULT} 2>&1
echo "[상태]" >> ${RESULT} 2>&1
if [ -z "'cat ${PATH_PASSWD} | egrep ${ACCOUNT}'" ];	then 
	echo "양호" >> ${RESULT} 2>&1
elif [ ! -z "'cat ${PATH_PASSWD} | egrep ${ACCOUNT}'" ];	then 
	echo "취약" >> ${RESULT} 2>&1
fi

# echo "양호" >> ${RESULT} 2>&1
echo "[점검 기준 ]" >> ${RESULT} 2>&1
echo "양호: 불필요한 계정이 존재하지 않는 경우" >> ${RESULT} 2>&1
echo "취약: 불필요한 계정이 존재하는 경우" >> ${RESULT} 2>&1
echo "**** 불필요한 계정 점검 항목이 공란이 아닐 경우, userdel <user_name> 을 사용하여 삭제를 권고함 ****" >> ${RESULT} 2>&1
