#!/bin/sh
LANG=ko_KR.UTF-8

CURRENT_PATH=`dirname $0`

NAME=`basename $0`

ETC_PATH="/etc"

RESULT="$CURRENT_PATH/result_$NAME.txt"

#리눅스 버전 : Debian 7
#계정관리 1.6 패스워드 사용규칙 적용
#주요정보통신기반시설_12p참고
echo "[LDv7-1.06]" > ${RESULT} 2>&1
echo "패스워드 사용규칙 적용" >> ${RESULT} 2>&1
echo "[점검현황]" >> ${RESULT} 2>&1
echo "1. 패스워드 최소 길이 정책 적용" >> ${RESULT} 2>&1
MIN_LEN=$(awk '/PASS_MIN_LEN[[:space:]][[:digit:]]/' /etc/login.defs)
echo $MIN_LEN >> ${RESULT} 2>&1
echo "2. 패스워드 최대 사용 기간 설정" >> ${RESULT} 2>&1	
MAX_DAYS=$(awk '/PASS_MAX_DAYS[[:space:]][[:digit:]]/' /etc/login.defs)
echo $MAX_DAYS >> ${RESULT} 2>&1
echo "3. 패스워드 최소  사용 기간 설정" >> ${RESULT} 2>&1	
MIN_DAYS=$(awk '/PASS_MIN_DAYS[[:space:]][[:digit:]]/' /etc/login.defs)
echo $MIN_DAYS >> ${RESULT} 2>&1
echo "4. 패스워드 실패시 잠금되는 횟수 설정" >> ${RESULT} 2>&1
TALLY=$(cat /etc/login.defs | egrep "LOGIN_RETRIES")
echo $TALLY >> ${RESULT} 2>&1
echo "[상태]" >> ${RESULT} 2>&1
STATUS="양호"
MIN_LEN=$(echo $MIN_LEN | sed "s/[^0-9]//g")
if [ ${MIN_LEN} -le 8 ]
then
	STATUS="취약"
fi

MAX_DAYS=$(echo $MAX_DAYS | sed "s/[^0-9]//g")
if [ ${MAX_DAYS} -gt 90 ]
then
	STATUS="취약"
fi

MIN_DAYS=$(echo $MIN_DAYS | sed "s/[^0-9]//g")
if [ ${MIN_DAYS} -ne 1 ]
then
	STATUS="취약"
fi

TALLY=$(echo $TALLY | sed -n "s/[^0-9]//g")
if [ ${TALLY} -gt 5 ]
then
STATUS="취약"
fi

echo $STATUS >> ${RESULT} 2>&1
echo "[점검 기준]" >> ${RESULT} 2>&1
echo "[양호]" >> ${RESULT} 2>&1
echo "1. 패스워드 최소 길이" >>  ${RESULT} 2>&1
echo "패스워드 최소 길이가 8자 이상으로 설정되어 있는 경우" >> ${RESULT} 2>&1
echo "2. 패스워드 최대 사용 기간" >>  ${RESULT} 2>&1
echo "패스워드 최대 사용기간이 90일(12주) 이하로 설정되어 있는 경우" >> ${RESULT} 2>&1
echo "3. 패스워드 최소 사용 기간" >> ${RESULT} 2>&1
echo "패스워드 최소 사용기간이 1일(1주)로 설정되어 있는 경우" >> ${RESULT} 2>&1
echo "4. 계정 잠금 임계 값 " >>  ${RESULT} 2>&1
echo "계정 잠금 임계값이 5 이하의 값으로 설정되어 있는 경우" >> ${RESULT} 2>&1

echo "[취약]" >> ${RESULT} 2>&1
echo "1. 패스워드 최소 길이" >>  ${RESULT} 2>&1
echo "패스워드 최소 길이가 8자 미만으로 설정되어 있는 경우" >>${RESULT} 2>&1
echo "2. 패스워드 최대 사용 기간" >>  ${RESULT} 2>&1
echo "패스워드 최대 사용기간이 90일(12주) 이하로 설정되어 있지 않는 경우" >> ${RESULT} 2>&1
echo "3. 패스워드 최소 사용 기간" >> ${RESULT} 2>&1
echo "패스워드 최소 사용기간이 1일(1주)로 설정되어 있지 않는 경우" >> ${RESULT} 2>&1
echo "4. 계정 잠금 임계 값 " >>  ${RESULT} 2>&1
echo "계정 잠금 임계값이 설정되어 있지 않거나, 5 이하의 값으로 설정되지 않은 경우" >> ${RESULT} 2>&1
