#!/bin/sh
LANG=ko_KR.UTF-8

CURRENT_PATH=`dirname $0`

NAME=`basename $0`

ETC_PATH="/etc"

RESULT="$CURRENT_PATH/result_$NAME.txt"

#리눅스 버전 : Debian 7
#계정관리 1.8 SU(Select User) 사용 제한
#주요정보통신기반시설_16p참고

echo "[LDv7-1.08]"  > ${RESULT} 2>&1
echo "SU(Select User) 사용 제한">> ${RESULT} 2>&1
echo "[점검현황]" >> ${RESULT} 2>&1
echo "1. wheel그룹(su 명령어 사용 그룹) 및 그룹 내 구성원 존재 여부" >> ${RESULT} 2>&1
GROUP=$(cat /etc/group | egrep wheel)
echo $GROUP >> ${RESULT} 2>&1

echo "2. /bin/su 권한과 소유 그룹 확인"  >> ${RESULT} 2>&1
ls -l /bin/su >> ${RESULT} 2>&1

echo "3. /usr/bin/su 권한과 소유 그룹 확인"  >> ${RESULT} 2>&1
ls -l /usr/bin/su-to-root >> ${RESULT} 2>&1

echo "4. 허용 그룹(su 명령어 사용 그룹) 설정 여부 확인"  >> ${RESULT} 2>&1
WHEEL=$(cat /etc/pam.d/su | egrep  pam_wheel.so)
echo "$WHEEL" >> ${RESULT} 2>&1

##### 상태 출력#####
echo "[상태]" >> ${RESULT} 2>&1
STATUS="양호"

#wheel그룹(su 명령어 사용 그룹) 및 그룹 내 구성원 존재 여부 확인
if [ -z "$GROUP" ] || [ -z $(cat /etc/group | egrep wheel | awk -F : '{print $4}') ]
then
	STATUS="취약"
fi

#/bin/su, /usr/bin/su 권한과 소유 그룹 확인
BINGROUP=$(ls -l /bin/su |awk -F ' ' "{print \$4}")
USRGROUP=$(ls -l /usr/bin/su-to-root |awk -F ' ' "{print \$4}")
if [ "$BINGROUP" != "wheel" ] || [ "$USRGROUP" != "wheel" ]
then
	STATUS="취약"
fi
for x in 1 2
do
	SU="/bin/su"
	if [ ${x} -eq 2 ]
	then
		SU="/usr/bin/su-to-root"	
	fi
	for i in 1 2 3 4
	do
			PERM=$(stat -c '%a' "${SU}" | awk -F '' "{print \$"${i}"}")
			if [ ${i} -eq 1 ] 
			then
				if [ ${PERM} -gt 4 ]
				then
					STATUS="취약"
				fi
			fi
			if [ ${i} -eq 3 ] 
			then
				if [ ${PERM} -gt 5 ]
				then
					STATUS="취약"
				fi
			fi
			if [ ${i} -eq 4 ] 
			then
				if [ ${PERM} -gt 0 ]
				then
					STATUS="취약"
				fi
			fi
	done
done

#허용 그룹(su 명령어 사용 그룹) 설정 여부 확인
if [ -z "$WHEEL" ]
then
	STATUS="취약"
fi

echo $STATUS >> ${RESULT} 2>&1

##### 점검 기준 출력 #####
echo "[점검 기준]" >> ${RESULT} 2>&1
echo "[양호]" >> ${RESULT} 2>&1
echo "su 명령어를 특정 그룹에 속한 사용자만 사용하도록 제한되어 있는 경우" >>${RESULT} 2>&1

echo "[취약]" >> ${RESULT} 2>&1
echo "su 명령어를 모든 사용자가 사용하도록 설정되어 있는 경우" >> ${RESULT} 2>&1

