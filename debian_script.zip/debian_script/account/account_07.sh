#!/bin/sh
LANG=ko_KR.UTF-8

CURRENT_PATH=`dirname $0`

NAME=`basename $0`

ETC_PATH="/etc"

RESULT="$CURRENT_PATH/result_$NAME.txt"

#리눅스 버전 : Debian 7
#계정관리 1.7 로그인이 불필요한 계정 shell 제한
#주요정보통신기반시설_30p참고

echo "[LDv7-1.07]"> ${RESULT} 2>&1
echo "로그인이 불필요한 계정 shell 제한" >> ${RESULT} 2>&1
echo "[점검현황]" >> ${RESULT} 2>&1
echo "쉘이 부여되지 않은 계정 " >> ${RESULT} 2>&1
USER=$(cat /etc/passwd | egrep "^daemon|^bin|^sys|^adm|^listen|^nobody|^nobody4|^noaccess|^diag|^operator|^games|^gopher" | egrep -v "/bin/false|nologin" | egrep -v "admin|systemd-network")
echo $USER >> ${RESULT} 2>&1
echo "[상태]" >> ${RESULT} 2>&1

STATUS="양호"
if [ -n "$USER" ]
then
	STATUS="취약"
fi 
echo $STATUS >> ${RESULT} 2>&1
echo "[점검 기준]" >> ${RESULT} 2>&1
echo "양호: 로그인이 필요하지 않은 계정에 /bin/false(nologin) 쉘이 부여되어 있는 경우" >> ${RESULT} 2>&1
echo "취약: 로그인이 필요하지 않은 계정에 /bin/false(nologin) 쉘이 부여되지 않은 경우" >> ${RESULT} 2>&1
